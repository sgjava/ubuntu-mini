This is Alok's 3.0.36+ kernel built with Marvin https://github.com/phjanderson/marvin
Included are 480p, 720p and 1080p versions. Make sure you select the correct kernel
since the MK802IV has 8188eu and ap6210 versions based on manufacture date. I added
the /system dir to the modules and firmware since that's where the kernel looks for
the ap6210 firmware. I also located the rkwifi.ko under /lib/modules/drivers/net, so
it can be loaded from /etc/modules as rkwifi.

To build 480P yourself:

o	Get latest kernel source from Alok's site instead of from Marvin project
o	Change the following in Linux3188/drivers/video/rockchip/hdmi/rk_hdmi.h:
	o	HDMI_VIDEO_DEFAULT_MODE to HDMI_720x480p_60HZ_4_3 instead of HDMI_1920x1080p_60HZ
o	Add the following to the end of Linux3188/drivers/video/display/screen/lcd_480p.c (it is missing):
	size_t get_fb_size(void)
	{
	    size_t size = 0;
	    #if defined(CONFIG_THREE_FB_BUFFER)
	        size = ((H_VD)*(V_VD)<<2)* 3; //three buffer
	    #else
	        size = ((H_VD)*(V_VD)<<2)<<1; //two buffer
	    #endif
	    return ALIGN(size,SZ_1M);
	}
    ./marvin mrproper
    ./marvin platform picuntu3188
    ./marvin config mk802iv_rtl8188eu 480p (or whatever your mini PC is)
    ./marvin build

o	Kernels come from https://github.com/aloksinha2001/Linux3188
o	Firmware and modules come from http://www.g8.net/download/4.4/rootfs/picuntu-4-4-3-SKEL.tgz

I tested this on a MK-802IV with 8188eu and ap6210. depmod -a after first boot.

Flash recovery image to 0x00014000 for most ROMS. For Finless boot to bootloader
for dual boot or boot to recovery for Linux only boot.

uname -a

Linux ubuntu 3.0.36+ #1 SMP PREEMPT Thu Mar 20 18:53:17 EDT 2014 armv7l armv7l armv7l GNU/Linux


