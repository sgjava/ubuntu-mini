This is Alok's 3.0.8-alok+ kernel from PicUntu RC3 and comes in a VGA, 720P and 1080P
versions.

o	Kernel comes from http://www.arctablet.com/mirrors/picuntu/krnl-recov-3.0.8-alok-RC3.tgz
o	Firmware came from http://www.arctablet.com/mirrors/picuntu/picuntu-linuxroot-0.9-RC2.2.tgz
0	Modules came from http://www.arctablet.com/mirrors/picuntu/modules-3.0.8-alok-RC3.1.tgz

I tested this only on a MK-808, but since the wireless drivers are compiled as
modules you should be able to echo "module_name" >> /etc/modules (replace
module_name with actual module name) and depmod -a for your particular mini PC.

Flash recovery image to 0x00010000 for most ROMS. For Finless boot to bootloader
for dual boot or boot to recovery for Linux only boot.

uname -a

Linux ubuntu 3.0.8-alok+ #19 SMP PREEMPT Tue Feb 5 16:36:12 IST 2013 armv7l armv7l armv7l GNU/Linux

Changelog

PicUntu 0.9 RC 3

Changelog - Kernel - 3.0.8-alok+

    Cleaned the previous kernel
    Removed unwanted TV Tuner cards
    Bluetooth support retained
    All cpufreq governors now available - Try userspace, and hav fun.. (Read warning below)
    Default governor Ondemand
    Added Serial modules - FTD-SIO, pl2303, Garmin - for serial devices,
    Added Phone modems - For connecting Data card dongles
    Added UVC Camera support - Many users have been asking for this
    Added oprofiler support
    Added iptables
    Added NAT/Firewall (inc GRE) support - Now you can make your PicUntu a complete firewall
    Added USB 1.0 support - remember how your old USB hubs were not being used for bootup, well they should work now.
    DW_OTG_ debug report suppressed
    Added USB SCSI adapter - I have lots of SCSI harddisk lying around, and USB adapter for them, but they seemed not to work earlier.
    Added Pegasus network support
    FB set - all options enabled - you should have better control for fb setting.
    Added auxilary Video - If you have a USB LED,LCD screen lying around - try connecting to PIcUntu, should work. (in addition to HDMI) - required for in-car applications.
    Modules for USB Printer - now you should be able to connect USB printers to PicUntu
    Serial Modem drivers - Qualcom, NAVMAN,
    Added Joliet/UDF support - You should be able to connect USB CDROM
    NFS Client, NFS Server support for V3 , V4 added
    Ofcourse CIFS continues
    Integrated BCM40181, rtl8188eu support - so that you no longer need to separately look for modules for basic wifi
    Three graphic driver kernels - 1080p, 720, VGA are released.
    No it does not yet have support for MX1 wifi, RK802III/s - wifi - I am still hunting for the source. - A Kirby from Rikomagic was successful in getting us the source code for MT. (wifi + BT) trying to get that integrated now.

