This is olegk0's 3.0.8 kernel and it only comes in a 1080P+720P version.

o	Kernel comes from https://docs.google.com/folderview?usp=sharing&id=0B6QRwjacGTzCb0x0THEtSkxnbWM&tid=0B6QRwjacGTzCX0UyOXNGSU5iMGc
o	Firmware and modules come from https://docs.google.com/folderview?usp=sharing&id=0B6QRwjacGTzCb0x0THEtSkxnbWM&tid=0B6QRwjacGTzCX0UyOXNGSU5iMGc

I tested this only on a MK-808, but since the wireless drivers are compiled as
modules you should be able to echo "module_name" >> /etc/modules (replace
module_name with actual module name) and depmod -a for your particular mini PC.

Flash recovery image to 0x00010000 for most ROMS. For Finless boot to bootloader
for dual boot or boot to recovery for Linux only boot.

uname -a

Linux ubuntu 3.0.8+ #26 SMP PREEMPT Mon Mar 18 11:30:34 MSK 2013 armv7l armv7l armv7l GNU/Linux

WARNING
-made ​​specifically for mk808 (with fixed core voltage)
-no warranty, use at your own risk

Features
* 1920х1080, 1280х720 (it is checked)
* RAM at 400MHz
* Core dynamically 816 MHz - 1.51 Ghz (it is restricted only to core temperature)
* the second display interface is switched off
* the ion memory manager is switched off (+80mb RAM)
* Support for GPU (Mali) in the kernel + working modules
* Mali on 266MHz, but can turn to 400MHz
* Some changes to the kernel to support XVideo extension (for my xorg fb driver)
* ...

+flash recovery.img into recovery area

+your favorite Linux root place under linuxroot label (if you have not)

+add into /etc/modules
bcm40181
rk29-ipp
ump
disp_ump
mali
drm
mali_drm

/etc/rc.local
+add chmod 666 /dev/mali /dev/ump
to comment out (#) all lines with fbset (if is)

+rewrite modules (/lib/modules) and firmwares (/lib/firmware) from mod+fw.tar.gz
(then "depmod -a" and reboot)

+for Mali also needed libraries from here (only mali400_2.1-13_armhf.deb), if not working - look here

to delete files /usr/share/X11/xorg.conf.d/*mali*.conf(if is)

Updated 20.03.2013(some corrections under the new video driver)

-------------------------------------------------------------------------------------------------------------------
in folder video_drv - compiled (for ubuntu quantal and debian wheezy) xorg fb driver with XVideo(some acceleration of output video in full screen) and Mali support


Updated 27.02.2013(fixed auto set display mode(no need more fbset in rc.local))
Updated 20.03.2013 (subfolder tst)(acceleration of rendering GPU) new xorg.conf

caution alpha version

+ place rk30fb_drv.so into /usr/lib/xorg/modules/drivers/ and xorg.conf into /etc/X11

