This is Alok's 3.0.8+ kernel from PicUntu RC2 and it only comes in a 1080P
version.

o	Kernel comes from https://github.com/sgjava/byoc/raw/master/picuntu/PicuntuKernelInstaller4.zip
o	Firmware and modules come from http://www.arctablet.com/mirrors/picuntu/picuntu-linuxroot-0.9-RC2.2.tgz

I tested this only on a MK-808, but since the wireless drivers are compiled as
modules you should be able to echo "module_name" >> /etc/modules (replace
module_name with actual module name) and depmod -a for your particular mini PC.

Flash recovery image to 0x00010000 for most ROMS. For Finless boot to bootloader
for dual boot or boot to recovery for Linux only boot.

uname -a

Linux ubuntu 3.0.8+ #1 SMP PREEMPT Thu Nov 29 23:53:42 CET 2012 armv7l armv7l armv7l GNU/Linux

Changelog

PicUntu 0.9 RC 2

First Release - 0.9b

    Removed the bug 8188eu was going into power saving mode - added
    The system now tries to connect to all three types of network - by default
        wlan0, eth0, usbnet0 
    Installed both, 8188eu (for UG802) and bcm41081 (for MK808) modules
    Fixed OTG_DWC error that fills up the log file

Hardware Tested

Core devices

    MK808
    UG802
    AK802-III 

Accessories

    USB Hubs
    Wireless Keyboards
        Chicony, Riit 12-13 
    USB Thumb drives
        4GB, 8GB 16GB, 32GB, 64GB 
    USB ethernet
        BobjGear Ethernet adapter, JP10801B no9700, USB 2.0 to fast ethernet adapter 
    USB External Hard disk
        1TB: Seagate, WDTV, Buffalo, 2TB: Lacie,WDTV
        Can also install on USB External disk. 
    USB sound card
    HDMI-to-VGA convertor

