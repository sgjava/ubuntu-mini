This is Alok's 3.0.36+ kernel built with Marvin https://github.com/phjanderson/marvin
Included are 720p and 1080p versions. Make sure you select the correct kernel
since the MK802IV has 8188eu and ap6210 versions based on manufacture date.

o	Kernels come from https://github.com/phjanderson/Linux3188
o	Firmware and modules come from http://www.g8.net/download/4.4/rootfs/picuntu-4-4-3-SKEL.tgz

I tested this only on a MK-802IV with 8188eu. depmod -a after first boot.

Flash recovery image to 0x00014000 for most ROMS. For Finless boot to bootloader
for dual boot or boot to recovery for Linux only boot.

uname -a

Linux ubuntu 3.0.36+ #1 SMP PREEMPT Thu Mar 20 18:53:17 EDT 2014 armv7l armv7l armv7l GNU/Linux


