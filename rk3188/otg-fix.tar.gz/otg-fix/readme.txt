These are patched files that fix dwc_otg: support non DWORD-aligned buffer for DMA.
See http://www.freaktab.com/showthread.php?19955-fix-it-and-pach-%28dwc_otg-support-non-DWORD-aligned-buffer-for-DMA%29

I've only tested this on a MK802IV with Alok's 3.0.36+ kernel.

After you download the kernel source:

o	Copy files to drivers/usb/dwc_otg
o	Compile kernel as normal

