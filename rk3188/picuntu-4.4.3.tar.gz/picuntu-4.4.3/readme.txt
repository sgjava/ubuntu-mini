This is Alok's 3.0.36+ kernel from PicUntu 4.4.3 and it comes in 720P and 1080P
versions. Make sure you select the correct kernel since the MK802IV has 8188eu
and ap6210 versions based on manufacture date.

o	Kernels come from:
		o PicUntu 4.4.3 - Pre-Jul - 720p http://www.g8.net/download/4.4/kernel/picuntu-4-4-3.8188eu.720.img
		o PicUntu 4.4.3 - Pre-Jul - 1080p http://www.g8.net/download/4.4/kernel/picuntu-4-4-3.8188eu.1080p.img
		o PicUntu 4.4.3 - PostJul - 720p http://www.g8.net/download/4.4/kernel/picuntu-4-4-3.ap6210.720.img
		o PicUntu 4.4.3 - PostJul - 1080p http://www.g8.net/download/4.4/kernel/picuntu-4-4-3.ap6210.1080p.img
o	Firmware and modules come from http://www.g8.net/download/4.4/rootfs/picuntu-4-4-3-SKEL.tgz

I tested this only on a MK-802IV with 8188eu. depmod -a after first boot.

Flash recovery image to 0x00010000 for most ROMS. For Finless boot to bootloader
for dual boot or boot to recovery for Linux only boot.

uname -a

Linux ubuntu 3.0.36+ #1 SMP PREEMPT Sun Sep 29 04:42:36 IST 2013 armv7l armv7l armv7l GNU/Linux

Modules included

More than 180+ modules have been included. Notable of them are:

ntfs, sata, cramfs, nfs, cifs, 20+ remotecontrols, network ethernet drivers,
IR controllers, GPS (several), Joystick, Touchscreen, bluetooth support etc. etc.

What works

o	Almost everything that should work on a good modern Linux system.
o	Sound, Wifi etc.

What still does not work

o	MALI hardware (that does not mean you cannot play movies/video... you can)
o	Bluetooth - internal.

